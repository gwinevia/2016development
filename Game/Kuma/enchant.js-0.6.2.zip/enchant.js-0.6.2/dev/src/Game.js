/**
 * enchant.Core is moved to enchant.Core from v0.6
 * @type {*}
 */
enchant.Game = enchant.Core;